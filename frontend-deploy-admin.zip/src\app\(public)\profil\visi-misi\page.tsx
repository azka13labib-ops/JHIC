import type { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { 
  Target, 
  Compass, 
  GraduationCap, 
  Laptop, 
  Sparkles, 
  Sprout, 
  Handshake, 
  Check, 
  Heart,
  Building2,
  Microscope,
  BookOpen,
  Mic,
  Trophy,
  Landmark,
  Tv,
  Trees,
  ArrowRight
} from 'lucide-react';

export const metadata: Metadata = {
  title: 'Visi, Misi & Fasilitas | SMA PGRI 1 Lumajang',
  description: 'Visi, misi, tujuan pendidikan, tata nilai luhur, dan fasilitas unggulan SMA PGRI 1 Lumajang dalam mendidik generasi penerus bangsa.',
};

export const revalidate = 86400;

export default function VisiMisiPage() {
  const missions = [
    {
      no: '01',
      title: 'Pendidikan Karakter & Spiritual',
      desc: 'Menyelenggarakan pembelajaran yang berlandaskan iman, taqwa, serta nilai-nilai budi pekerti luhur guna mencetak peserta didik berakhlakul karimah.',
      icon: Heart,
    },
    {
      no: '02',
      title: 'Keunggulan Akademik & Prestasi',
      desc: 'Mengembangkan kurikulum yang adaptif, inovatif, dan berstandar nasional untuk mengoptimalkan potensi intelektual dan prestasi di berbagai kompetisi sains maupun seni.',
      icon: GraduationCap,
    },
    {
      no: '03',
      title: 'Keterampilan Digital & Sertifikasi Industri',
      desc: 'Membekali peserta didik dengan literasi digital tingkat lanjut, keterampilan teknologi informasi, dan sertifikasi keahlian yang diakui industri global.',
      icon: Laptop,
    },
    {
      no: '04',
      title: 'Kepemimpinan, Riset & Kreativitas Mandiri',
      desc: 'Menumbuhkan karakter kepemimpinan, kemampuan riset ilmiah, dan daya cipta mandiri melalui kegiatan kesiswaan serta Projek Penguatan Profil Pelajar Pancasila (P5).',
      icon: Sparkles,
    },
    {
      no: '05',
      title: 'Wawasan Lingkungan & Sosial',
      desc: 'Mewujudkan budaya sekolah yang ramah anak, peduli kelestarian lingkungan hidup, tanggap bencana, dan menjunjung tinggi kearifan lokal.',
      icon: Sprout,
    },
    {
      no: '06',
      title: 'Kemitraan Strategis Dunia Kerja',
      desc: 'Membangun jejaring kolaborasi erat dengan Perguruan Tinggi Terkemuka, Industri, Dunia Usaha, dan Lembaga Sertifikasi Profesi.',
      icon: Handshake,
    },
  ];

  const goals = [
    {
      category: 'Jangka Pendek',
      points: [
        'Peningkatan rata-rata nilai akademik dan tingkat kelulusan 100%.',
        'Peningkatan prestasi ekstrakurikuler di tingkat kabupaten dan provinsi.',
        'Implementasi penuh e-learning dan manajemen sekolah berbasis digital.',
      ],
    },
    {
      category: 'Jangka Menengah',
      points: [
        'Meningkatkan persentase lulusan yang diterima di PTN favorit dan ikatan dinas hingga >70%.',
        'Mencapai prestasi medali emas pada ajang LKS, OSN, dan FLS2N tingkat nasional.',
        'Penguatan kemitraan strategis dengan lebih dari 20 industri terkemuka.',
      ],
    },
    {
      category: 'Jangka Panjang',
      points: [
        'Menjadi sekolah rujukan nasional untuk integrasi kurikulum akademik dan vokasional digital.',
        'Melahirkan wirausahawan muda dan profesional yang berdaya saing di kancah internasional.',
        'Menjadi pusat keunggulan (Center of Excellence) pendidikan berwawasan global di Jawa Timur.',
      ],
    },
  ];

  const coreValues = [
    { code: 'S', name: 'Santun', desc: 'Menghormati sesama dan bertutur kata baik dalam setiap pergaulan.' },
    { code: 'M', name: 'Mandiri', desc: 'Mampu mengambil inisiatif, bertanggung jawab, dan menyelesaikan tantangan hidup.' },
    { code: 'A', name: 'Adaptif', desc: 'Cepat menyesuaikan diri dengan perkembangan zaman dan teknologi modern.' },
    { code: 'R', name: 'Religius', desc: 'Menjadikan nilai-nilai keagamaan sebagai pedoman utama bertindak.' },
    { code: 'T', name: 'Tangguh', desc: 'Pantang menyerah, ulet, dan selalu berorientasi pada pencapaian prestasi tertinggi.' },
  ];

  const facilities = [
    {
      icon: Laptop,
      name: 'Laboratorium Komputer & Multimedia',
      desc: '3 Lab ber-AC dengan PC Core i7, GPU grafis, fiber optic 500 Mbps, dan lisensi industri.',
      image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=800&auto=format&fit=crop',
      color: 'text-blue-600 bg-blue-50 border-blue-100',
    },
    {
      icon: Microscope,
      name: 'Laboratorium Sains & Riset Terpadu',
      desc: 'Peralatan praktikum Fisika, Kimia, & Biologi lengkap dengan mikroskop digital modern.',
      image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?q=80&w=800&auto=format&fit=crop',
      color: 'text-emerald-600 bg-emerald-50 border-emerald-100',
    },
    {
      icon: BookOpen,
      name: 'Perpustakaan Digital & Reading Lounge',
      desc: 'Ribuan koleksi buku fisik, e-library nasional, area baca lesehan nyaman & ruang diskusi.',
      image: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?q=80&w=800&auto=format&fit=crop',
      color: 'text-amber-600 bg-amber-50 border-amber-100',
    },
    {
      icon: Mic,
      name: 'Studio Podcast & Broadcasting',
      desc: 'Studio audio-visual peredam suara, mixer pro & kamera 4K untuk konten kreatif.',
      image: 'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?q=80&w=800&auto=format&fit=crop',
      color: 'text-purple-600 bg-purple-50 border-purple-100',
    },
    {
      icon: Trophy,
      name: 'Sarana Olahraga Multifungsi',
      desc: 'Lapangan outdoor & semi-indoor untuk Futsal, Basket, Voli & Bulutangkis standar resmi.',
      image: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=800&auto=format&fit=crop',
      color: 'text-rose-600 bg-rose-50 border-rose-100',
    },
    {
      icon: Landmark,
      name: 'Masjid & Pusat Ibadah Sekolah',
      desc: 'Sarana pembinaan spiritual dan sholat berjamaah yang representatif, asri & sejuk.',
      image: 'https://images.unsplash.com/photo-1564769625905-50e93615e769?q=80&w=800&auto=format&fit=crop',
      color: 'text-teal-600 bg-teal-50 border-teal-100',
    },
    {
      icon: Tv,
      name: 'Smart Classroom & Aula Pertemuan',
      desc: 'Kelas proyektor laser pintar & gedung aula serbaguna kapasitas 500 orang.',
      image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=800&auto=format&fit=crop',
      color: 'text-indigo-600 bg-indigo-50 border-indigo-100',
    },
    {
      icon: Trees,
      name: 'Kantin Sehat & Eco-Park Hijau',
      desc: 'Kantin higienis binaan Dinkes dan taman hijau asri untuk relaksasi dan istirahat siswa.',
      image: 'https://images.unsplash.com/photo-1519452635265-7b1fbfd1e4e0?q=80&w=800&auto=format&fit=crop',
      color: 'text-lime-600 bg-lime-50 border-lime-100',
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header Banner */}
      <section className="relative bg-linear-to-b from-slate-50 via-white to-slate-50 text-slate-900 border-b border-slate-200 py-16 sm:py-20 overflow-hidden">
        <div className="container mx-auto px-4 relative z-10 text-center">
          <div className="inline-flex items-center gap-2 bg-blue-50 border border-blue-100 rounded-full px-4 py-1.5 text-xs font-bold uppercase tracking-wider mb-4 text-blue-700">
            <Target className="w-3.5 h-3.5" /> Arah & Panduan Sekolah
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold mb-4 tracking-tight text-slate-900">
            Visi, Misi & Fasilitas Sekolah
          </h1>
          <p className="text-slate-600 max-w-2xl mx-auto text-base sm:text-lg leading-relaxed">
            Komitmen strategis dan sarana prasarana modern SMA PGRI 1 Lumajang dalam mendidik generasi unggul masa depan.
          </p>

          {/* Breadcrumb */}
          <div className="flex justify-center items-center gap-2 text-xs sm:text-sm text-slate-500 mt-6">
            <Link href="/" className="hover:text-blue-600 transition-colors">Home</Link>
            <span>/</span>
            <span>Profil</span>
            <span>/</span>
            <span className="text-slate-900 font-semibold">Visi, Misi & Fasilitas</span>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-16">
        
        {/* 1. Visi Section */}
        <div className="max-w-5xl mx-auto mb-20">
          <div className="bg-linear-to-br from-blue-600 to-indigo-800 rounded-3xl p-8 sm:p-14 text-white shadow-xl relative overflow-hidden group">
            <Target className="absolute -right-10 -bottom-10 w-72 h-72 opacity-10 group-hover:scale-110 transition-transform duration-500" />
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider mb-6">
              <Compass className="w-3.5 h-3.5" /> Visi Utama Sekolah
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold leading-snug mb-6 text-amber-300">
              &ldquo;Terwujudnya Generasi Emas yang Religius, Unggul dalam Prestasi, Terampil dalam Teknologi, Berkarakter Mandiri, dan Berdaya Saing Global.&rdquo;
            </h2>
            <p className="text-blue-100 text-base sm:text-lg leading-relaxed max-w-3xl">
              Visi ini mencerminkan komitmen kuat SMA PGRI 1 Lumajang untuk tidak hanya mentransfer ilmu pengetahuan, melainkan juga menanamkan fondasi keimanan yang kokoh, kompetensi keahlian yang relevan dengan industri masa depan, serta kepribadian yang tangguh.
            </p>
          </div>
        </div>

        {/* 2. Misi Section */}
        <div className="max-w-5xl mx-auto mb-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900">Misi SMA PGRI 1 Lumajang</h2>
            <p className="text-slate-500 mt-2">Langkah-langkah strategis untuk mewujudkan visi sekolah secara konsisten</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {missions.map((item, idx) => {
              const IconComponent = item.icon;
              return (
                <div
                  key={idx}
                  className="bg-white rounded-2xl p-8 shadow-sm border border-slate-200 hover:shadow-md hover:border-blue-200 transition-all flex gap-5 items-start group"
                >
                  <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 font-bold group-hover:scale-110 transition-transform">
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-xs font-black text-blue-600 tracking-wider uppercase mb-1">Misi #{item.no}</div>
                    <h3 className="text-lg font-bold text-slate-900 mb-2">{item.title}</h3>
                    <p className="text-slate-600 text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 3. Core Values: S-M-A-R-T */}
        <div className="max-w-5xl mx-auto mb-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900">Tata Nilai Budaya (SMAGRISA S-M-A-R-T)</h2>
            <p className="text-slate-500 mt-2">Prinsip karakter yang dijiwai oleh seluruh civitas akademika</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {coreValues.map((val, idx) => (
              <div key={idx} className="bg-white rounded-2xl p-6 text-center shadow-sm border border-slate-200 hover:border-amber-400 hover:shadow-lg transition-all group">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center text-2xl font-black mb-4 group-hover:scale-110 transition-transform">
                  {val.code}
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">{val.name}</h3>
                <p className="text-slate-600 text-xs leading-relaxed">{val.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* 4. Tujuan Pendidikan */}
        <div className="max-w-5xl mx-auto mb-24">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900">Tujuan Strategis Pendidikan</h2>
            <p className="text-slate-500 mt-2">Target pencapaian berjenjang demi kualitas berkelanjutan</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {goals.map((g, i) => (
              <div key={i} className="bg-white rounded-2xl p-8 shadow-sm border border-slate-200 flex flex-col justify-between">
                <div>
                  <div className="inline-block bg-blue-100 text-blue-700 text-xs font-bold px-3 py-1 rounded-full mb-4">
                    {g.category}
                  </div>
                  <ul className="space-y-3">
                    {g.points.map((pt, j) => (
                      <li key={j} className="text-sm text-slate-600 flex items-start gap-2.5">
                        <Check className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                        <span>{pt}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 5. Fasilitas & Sarana Prasarana Kampus (Under Visi Misi with Photos) */}
        <div id="fasilitas" className="max-w-6xl mx-auto pt-10 border-t border-slate-200/80 scroll-mt-24">
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-full px-4 py-1.5 text-xs font-bold uppercase tracking-wider mb-3 text-blue-700">
              <Building2 className="w-3.5 h-3.5" /> Sarana & Prasarana Unggulan
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Fasilitas Kampus Modern
            </h2>
            <p className="text-slate-600 max-w-2xl mx-auto mt-2 text-sm sm:text-base leading-relaxed">
              Mendukung ekosistem belajar yang nyaman, interaktif, dan berstandar industri demi mencetak lulusan berprestasi.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {facilities.map((fac, idx) => {
              const Icon = fac.icon;
              return (
                <div
                  key={idx}
                  className="bg-white rounded-3xl overflow-hidden border border-slate-200/90 hover:border-blue-300 shadow-xs hover:shadow-xl transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between group"
                >
                  <div>
                    {/* Facility Image with Hover Zoom */}
                    <div className="relative h-44 w-full overflow-hidden bg-slate-100">
                      <Image
                        src={fac.image}
                        alt={fac.name}
                        fill
                        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
                        className="object-cover group-hover:scale-108 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-linear-to-t from-black/40 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />
                      <div className="absolute top-3 left-3">
                        <div className={`w-9 h-9 rounded-xl ${fac.color} backdrop-blur-md bg-white/90 flex items-center justify-center shadow-md`}>
                          <Icon className="w-5 h-5" />
                        </div>
                      </div>
                    </div>

                    <div className="p-5">
                      <h3 className="text-sm sm:text-base font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors leading-snug">
                        {fac.name}
                      </h3>
                      <p className="text-slate-600 text-xs leading-relaxed">
                        {fac.desc}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Dedicated Page Link CTA */}
          <div className="text-center mt-10">
            <Link
              href="/profil/fasilitas"
              className="inline-flex items-center gap-2 px-6 py-3 bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-200 text-slate-700 hover:text-blue-700 font-bold rounded-2xl text-xs sm:text-sm transition-all shadow-2xs group cursor-pointer"
            >
              <span>Lihat Detail Spesifikasi Semua Fasilitas Lengkap</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>

        {/* Quick Navigation Footer */}
        <div className="max-w-4xl mx-auto mt-20 pt-10 border-t border-slate-200 flex flex-wrap justify-between items-center gap-4">
          <Link href="/profil/sejarah" className="inline-flex items-center gap-2 text-slate-600 font-semibold hover:text-blue-600">
            <span>&larr;</span> Baca Sejarah Singkat
          </Link>
          <Link href="/profil/sambutan" className="inline-flex items-center gap-2 text-blue-600 font-semibold hover:underline">
            Lanjut ke Sambutan Kepala Sekolah <span>&rarr;</span>
          </Link>
        </div>

      </div>
    </div>
  );
}
