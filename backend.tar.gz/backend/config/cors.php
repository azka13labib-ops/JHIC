<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Cross-Origin Resource Sharing (CORS) Configuration
    |--------------------------------------------------------------------------
    |
    | Here you may configure your settings for cross-origin resource sharing
    | or "CORS". This determines what cross-origin operations may execute
    | in web browsers. You are free to adjust these settings as needed.
    |
    */

    'paths' => ['api/*', 'sanctum/csrf-cookie'],

    'allowed_methods' => ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],

    'allowed_origins' => [env('FRONTEND_URL', 'http://localhost:3000'), 'http://localhost:3000', 'http://cp.localhost:3000', 'https://smaspgri1lumajang.sch.id', 'https://cp.smaspgri1lumajang.sch.id', 'http://192.168.1.25:3001'],

    'allowed_origins_patterns' => [
        '#^https?://.*\.localhost(:[0-9]+)?$#',
        '#^https?://.*\.smaspgri1lumajang\.sch\.id$#',
    ],

    'allowed_headers' => ['Content-Type', 'X-Requested-With', 'Authorization', 'Accept', 'Origin'],

    'exposed_headers' => [],

    'max_age' => 86400,

    'supports_credentials' => true,

];
